/*Основы программирования на C++
Урок 7. Циклы for и алгоритмы на циклах*/

//Циклы for

//Задача 1. Кукушка (цикл for).

#include <iostream>

int main()
{
    std::cout << "Enter the time: ";
    int hour;
    std::cin >> hour;

    for (; hour <= 0 || hour > 12; )
    {
        std::cout << "Time must be between 1 and 12. Enter the time: ";
        std::cin >> hour;
    }

    for (int count = 0; count < hour; ++count)
        std::cout << "Cuckoo!\n";

    return 0;
}
