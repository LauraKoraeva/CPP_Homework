#include "ram.h"

int buffer[8] = { 0 };