#pragma once

extern int buffer[8];
