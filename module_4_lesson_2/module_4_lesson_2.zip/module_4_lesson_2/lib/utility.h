#pragma once

bool correctInput(int input);