/*Основы программирования на C++
Урок 1. Вводный модуль. Первая программа*/

//Что такое программирование. Первая программа

#include <iostream>

int main() {
   
  std::cout << "Hello World!\n";
  
  std::cout << "Hello Laura!\n";
}
  