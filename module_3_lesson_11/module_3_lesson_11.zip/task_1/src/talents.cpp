#include <iostream>
#include "talents.h"

void Swimming::showTalent()
{
    std::cout << "Swim";
}

void Dancing::showTalent()
{
    std::cout << "Dance";
}

void Counting::showTalent()
{
    std::cout << "Count";
}