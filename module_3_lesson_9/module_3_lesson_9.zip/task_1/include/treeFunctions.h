#pragma once
#include "Branch.h"

Branch* createTree();

void populateTree(Branch* tree);