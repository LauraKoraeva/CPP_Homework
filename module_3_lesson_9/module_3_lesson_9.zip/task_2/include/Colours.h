#pragma once

enum Colours
{
    RED = 1,
    GREEN,
    BLUE,
    NONE,
};

void printColour(int colourIndex);