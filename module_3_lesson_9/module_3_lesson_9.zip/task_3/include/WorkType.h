#pragma once

enum WorkType
{
    A = 1,
    B,
    C,
};

void printWorkType(int type);